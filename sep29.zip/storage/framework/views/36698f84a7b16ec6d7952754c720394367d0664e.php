<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    
   <title><?php echo $__env->yieldContent('title'); ?></title>
   <?php echo $__env->make('frontend.partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <style type="text/css">
     <?php echo $__env->yieldContent('css'); ?>
   </style>
  </head>
  <body>

    <!-- preloader start -->
    <div class="preloader">
      <div class="wrapper-triangle">
        <div class="pen">
          <div class="line-triangle">
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
          </div>
          <div class="line-triangle">
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
          </div>
          <div class="line-triangle">
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
            <div class="triangle"></div>
          </div>
        </div>
      </div>
    </div>
    <!-- preloader end -->

    <div class="page">

      
      <?php echo $__env->make('frontend.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->yieldContent('content'); ?>

      
      <?php echo $__env->make('frontend.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
    <!-- div page end -->


    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>

    <?php echo $__env->make('frontend.partial.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



      <?php echo $__env->yieldContent('script'); ?>
	
</html>