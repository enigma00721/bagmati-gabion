<!-- Javascript-->
    <!-- <script src="<?php echo e(asset('js/core.min.js')); ?>"></script> -->
    <script src="<?php echo e(asset('js/core1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
	
