<!-- Javascript-->
    <!-- <script src="{{asset('js/core.min.js')}}"></script> -->
    <script src="{{asset('js/core1.min.js')}}"></script>
    <script src="{{asset('js/script.js')}}"></script>
	
